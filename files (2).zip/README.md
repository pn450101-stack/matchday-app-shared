# Accrington Stanley Academy Matchday App — Setup Guide

## What this app does

- **Squad** — add players with number, name, position, and a photo link
- **Live score & clock** — kick off, minute-by-minute clock, auto half-time and full-time posts
- **Log Goal** — one tap logs a goal for your team *or* the opponent
- **Fixtures** — upcoming matches with date, time, venue, location, competition
- **Lineup** — pick your Starting XI, set a formation, and share it laid out by position (forwards → midfield → defence → keeper)
- **Post-Match Quotes** — add a manager or player quote with their name and role, with an optional photo/video link
- **Man of the Match** — enter each player's assists and a rating (goals count automatically from the goals you logged); the app ranks everyone and lets you crown a MOTM
- **Share to socials** — every update (goal, half-time, full-time, lineup, quote, MOTM) opens a ready-made post you send with one tap, either through your phone's share sheet or straight to X/Facebook/WhatsApp/Telegram's own compose screen

**Important limit to know:** right now, all data (squad, scores, fixtures) is saved only in the browser on whichever phone/device you're using it on. It does **not** sync between different people's phones yet — that needs a shared login system, which is a separate upgrade we can do next.

---

## Part 1 — Put the app online (10–15 minutes)

You'll use two free websites: **GitHub** (stores your files) and **Vercel** (makes them into a live website).

### Step 1: Create your accounts
1. Go to **github.com** → click **Sign up** → make a free account.
2. Go to **vercel.com** → click **Sign Up** → choose **Continue with GitHub** (this links the two automatically).

### Step 2: Create a repository (a folder for your app)
1. On GitHub, click the **+** icon top-right → **New repository**.
2. Name it `matchday-app`.
3. Leave it **Public**, don't tick any extra boxes.
4. Click **Create repository**.

### Step 3: Upload the files
1. On your new repository's page, click **uploading an existing file** (a blue link in the middle of the page).
2. Drag in all 5 files from this download: `index.html`, `manifest.json`, `sw.js`, `icon-192.png`, `icon-512.png`.
3. Scroll down, click **Commit changes**.

### Step 4: Deploy it with Vercel
1. Go to **vercel.com/new**.
2. Find `matchday-app` in the list and click **Import**.
3. Leave every setting as default and click **Deploy**.
4. After about a minute, you'll get a live link like `matchday-app-yourname.vercel.app` — that's your app's permanent web address.

### Step 5: Update it later
Whenever you want to change something, go back to your GitHub repository, click on a file, click the pencil (✏️) icon to edit it, and commit the change — Vercel automatically re-deploys within a minute or two.

---

## Part 2 — Get it on your phone

### The easy way (works today, no extra steps)
1. Open your Vercel link on your Android phone in Chrome.
2. Tap the **⋮** menu → **Add to Home Screen** (or you may see a banner offering this automatically).
3. It now sits on your home screen with your icon, opens full-screen with no browser bar, and works like a normal app.

This is a real installed app (a "PWA") — most clubs never need anything more than this.

### The fuller way — an actual installable app file (.apk)
Only do this if you want a file you can send someone to install directly, or plan to eventually publish on the Google Play Store.

1. Go to **pwabuilder.com**.
2. Paste in your Vercel link and click **Start**.
3. Click **Package for stores** → choose **Android**.
4. Download the generated **.apk** file (for direct install) — download it to your phone and open it to install (you may need to allow "install from unknown sources" once, in your phone's settings).
5. If you ever want it on the **Google Play Store**, PWABuilder can also generate an **.aab** file, but publishing there needs a one-off $25 Google Play developer account and a privacy policy page (ask me if you get to that point — happy to help).

---

## What's next

- **Real app icon/crest**: swap `icon-192.png` and `icon-512.png` for your official club badge (same filenames) and re-upload to GitHub.
- **Shared multi-user login** (so the media team and coaching staff all edit the same live match together): this needs a proper backend — I'd recommend Supabase, which is free and built for exactly this. Say the word and I'll build that version next.
